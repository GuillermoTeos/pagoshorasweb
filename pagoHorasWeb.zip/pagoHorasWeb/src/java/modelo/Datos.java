/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Lab10
 */
public class Datos {

    private String empleado;
    private double valorHora;
    private double cantidadHoras;
    private double cantidadHorasNormales;
    private double valorHorasNormales;
    private double cantidadHorasExtra;
    private double valorHorasExtra;
    private double totalPagar;

    public Datos() {
        this.empleado = "";
        this.valorHora = 0.0;
        this.cantidadHoras = 0.0;
        this.cantidadHorasNormales = 0.0;
        this.valorHorasNormales = 0.0;
        this.cantidadHorasExtra = 0.0;
        this.valorHorasExtra = 0.0;
        this.totalPagar = 0.0;
    }

    public String getEmpleado() {
        return empleado;
    }

    public void setEmpleado(String empleado) {
        this.empleado = empleado;
    }

    public double getValorHora() {
        return valorHora;
    }

    public void setValorHora(double valorHora) {
        this.valorHora = valorHora;
    }

    public double getCantidadHoras() {
        return cantidadHoras;
    }

    public void setCantidadHoras(double cantidadHoras) {
        this.cantidadHoras = cantidadHoras;
    }

    public double getCantidadHorasNormales() {
        return cantidadHorasNormales;
    }

    public void setCantidadHorasNormales(double cantidadHorasNormales) {
        this.cantidadHorasNormales = cantidadHorasNormales;
    }

    public double getValorHorasNormales() {
        return valorHorasNormales;
    }

    public void setValorHorasNormales(double valorHorasNormales) {
        this.valorHorasNormales = valorHorasNormales;
    }

    public double getCantidadHorasExtra() {
        return cantidadHorasExtra;
    }

    public void setCantidadHorasExtra(double cantidadHorasExtra) {
        this.cantidadHorasExtra = cantidadHorasExtra;
    }

    public double getValorHorasExtra() {
        return valorHorasExtra;
    }

    public void setValorHorasExtra(double valorHorasExtra) {
        this.valorHorasExtra = valorHorasExtra;
    }

    public double getTotalPagar() {
        return totalPagar;
    }

    public void setTotalPagar(double totalPagar) {
        this.totalPagar = totalPagar;
    }
    
    
    
    

}
