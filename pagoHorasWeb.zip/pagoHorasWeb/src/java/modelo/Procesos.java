/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Lab10
 */
public class Procesos {

    public Datos calcular(Datos d) {
        // horas normales
        if (d.getCantidadHoras() <= 44) {
            d.setCantidadHorasNormales(d.getCantidadHoras());
            d.setValorHorasNormales(d.getCantidadHorasNormales() * d.getValorHora());
        } else {
            // horas normales
            d.setCantidadHorasNormales(44.0);
            d.setValorHorasNormales(d.getCantidadHorasNormales() * d.getValorHora());

            // horas extra
            d.setCantidadHorasExtra(d.getCantidadHoras() - 44);
            d.setValorHorasExtra((d.getCantidadHoras() - 44) * (d.getValorHora() * 2));
        }
        d.setTotalPagar(d.getValorHorasNormales() + d.getValorHorasExtra());
        return d; 
    }
}
